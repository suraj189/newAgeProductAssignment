export  const CompletedTask = [{
    sl: 1, taskName: "Aligment issue in Garage cabinet", startDate: "2021-03-09", endDate: "2021-03-05",
    endDate: "2021-03-10", assignee: "Bibhu", category: "NAP Bug Tak ", status: "In Qc", jiraId: "NAPDI-1287", mockUp: "Link", otherNotes: ""
},
{
    sl: 2, taskName: "Kamode Page pop-up", startDate: "2021-03-09",
    endDate: "2021-03-09", endDate: "2021-03-09", assignee: "Bibhu", category: "Nap Dev", status: "In Deployment", jiraId: "NAPDI-1287", mockUp: "Link", otherNotes: ""
},
{
    sl: 3, taskName: "Reducing the size live chat ", startDate: "2021-02-23",
    endDate: "2021-02-20", endDate: "2021-04-08", assignee: "Tanzil", category: "Nap Project", status: "on Hold", jiraId: "NAPDI-1287", mockUp: "Link", otherNotes: "This Project is hold till April 8th"
},
{
    sl: 4, taskName: "Remove the hp animation", startDate: "2021-03-09",
    endDate: "2021-03-09", endDate: "2021-03-09", assignee: "Bibhu", category: "Nap Dev", status: "In Deployment", jiraId: "NAPDI-1295", mockUp: "Link", otherNotes: "Qc Completedand working and working on Qc"
}];


export  const ProgressTask = [
    {
        sl: 1, taskName: "Contact Us Live chat Responsive Issue", startDate: "2021-03-09", endDate: "2021-03-05",
        endDate: "2021-03-10", assignee: "Bibhu", category: "NAP Bug Tak ", status: "In Qc", jiraId: "NAPDI-1287", mockUp: "Link", otherNotes: ""
    },
    {
        sl: 2, taskName: "Contact Us Live chat Deployment", startDate: "2021-03-09",
        endDate: "2021-03-09", endDate: "2021-03-09", assignee: "Bibhu", category: "Nap Dev", status: "In Deployment", jiraId: "NAPDI-1287", mockUp: "Link", otherNotes: ""
    },
    {
        sl: 3, taskName: "Cooking Appliancess", startDate: "2021-02-23",
        endDate: "2021-02-20", endDate: "2021-04-08", assignee: "Tanzil", category: "Nap Project", status: "on Hold", jiraId: "NAPDI-1287", mockUp: "Link", otherNotes: "This Project is hold till April 8th"
    },
    {
        sl: 4, taskName: "Update 404 Page nap", startDate: "2021-03-09",
        endDate: "2021-03-09", endDate: "2021-03-09", assignee: "Bibhu", category: "Nap Dev", status: "In Deployment", jiraId: "NAPDI-1295", mockUp: "Link", otherNotes: "Qc Completedand working and working on Qc"
    }
]

